import React from 'react'

export default function About() {
    return (
            <React.Fragment><h1>About us</h1></React.Fragment>
    )
}
