import React from 'react'
import TopNav from './TopNav'

export default function Header() {
    return (
        <React.Fragment>
            <TopNav />
        </React.Fragment>
        
    )
}